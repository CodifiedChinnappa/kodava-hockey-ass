import { ResetForm } from "@/components/backOffice/auth/reset-form";

const ResetPage = () => {
  return ( 
    <ResetForm />
  );
}
 
export default ResetPage;