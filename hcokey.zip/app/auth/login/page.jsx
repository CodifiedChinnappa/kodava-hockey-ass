import { LoginForm } from "@/components/backOffice/auth/login-form";

const LoginPage = () => {
  return ( 
    <LoginForm />
  );
}
 
export default LoginPage;