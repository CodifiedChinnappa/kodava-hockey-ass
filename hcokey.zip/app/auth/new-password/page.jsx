import { NewPasswordForm } from "@/components/backOffice/auth/new-password-form";

const NewPasswordPage = () => {
  return ( 
    <NewPasswordForm />
   );
}
 
export default NewPasswordPage;