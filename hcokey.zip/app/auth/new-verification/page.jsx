import { NewVerificationForm } from "@/components/backOffice/auth/new-verification-form";

const NewVerificationPage = () => {
  return ( 
    <NewVerificationForm />
   );
}
 
export default NewVerificationPage;