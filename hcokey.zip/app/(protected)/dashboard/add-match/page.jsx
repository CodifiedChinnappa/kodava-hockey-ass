import { AddMatchForm } from "@/components/backOffice/dashboard/add-match-form";

const MatchPage = () => {
  return ( 
    <AddMatchForm />
  );
}
 
export default MatchPage;