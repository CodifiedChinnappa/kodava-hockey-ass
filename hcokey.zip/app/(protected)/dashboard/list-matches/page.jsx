import { ListMatches } from "@/components/backOffice/dashboard/list-matches";

const MatchPage = () => {
  return <ListMatches />;
};

export default MatchPage;
