import { TournamentForm } from "@/components/backOffice/dashboard/tournament-form";

const TournamentPage = () => {
  return ( 
    <TournamentForm />
  );
}
 
export default TournamentPage;