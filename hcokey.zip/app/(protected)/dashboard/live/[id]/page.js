import { LiveScore } from "@/components/backOffice/dashboard/live-score";

const LivePage = () => {
  return <LiveScore />;
};

export default LivePage;
