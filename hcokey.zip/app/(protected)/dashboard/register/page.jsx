import { RegisterForm } from "@/components/backOffice/auth/register-form";

const RegisterPage = () => {
  return ( 
    <RegisterForm />
  );
}
 
export default RegisterPage;