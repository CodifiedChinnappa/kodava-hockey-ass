import { FamilyForm } from "@/components/backOffice/dashboard/family-form";

const FamilyPage = () => {
  return ( 
    <FamilyForm />
  );
}
 
export default FamilyPage;